# dice-roller-in-java
 Roll a dice.. in JAVA!
